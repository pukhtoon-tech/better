<!DOCTYPE html>
<html lang="en">

<head>

  <?php include 'include/top_links.php'; ?>

</head>

<body>
  <?php include 'include/header.php'; ?>

  <div class="container-fluid our-recommendation-section py-5">
    <div class="row">
      <div class="col-md-12  mx-auto">
        <div class="text-center our-recom mt-5 py-5">
          <h2><span>Our</span> <b>Recommendations</b></h2>
        </div>
        <div id="myCarousel" class="carousel slide" data-ride="carousel" data-interval="0">
          <!-- Carousel indicators -->
          <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
          </ol>
          <!-- Wrapper for carousel items -->
          <div class="carousel-inner">
            <div class="carousel-item active">
              <div class="row">
                <div class="col-sm-3 col-md-4 col-lg-3">
                  <div class="img-box card">
                    <img src="images/blink.jpg" class="img-fluid" alt="">
                    <div class="card-body">
                      <div class="icon-onhover mb-3">
                        <img class="img-fluid" src="images/iconfinder-link.svg" alt="iconfinder">
                      </div>
                      <p class="card-text better-card-text mb-0">Blink Two Camera Indoor System, 1080P HD in</p>
                      <div class="star-rating mt-2">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </div>
                    </div>

                  </div>
                </div>
                <div class="col-sm-3 col-md-4 col-lg-3">
                  <div class="img-box card">
                    <img src="images/gul-2.jpg" class="img-fluid" alt="">
                    <div class="card-body">
                      <div class="icon-onhover mb-3">
                        <img class="img-fluid" src="images/iconfinder-link.svg" alt="iconfinder">
                      </div>
                      <p class="card-text better-card-text mb-0">Blink Two Camera Indoor System, 1080P HD in</p>
                      <div class="star-rating mt-2">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-3 col-md-4 col-lg-3">
                  <div class="img-box card">
                    <img src="images/gul.jpg" class="img-fluid" alt="">
                    <div class="card-body">
                      <div class="icon-onhover mb-3">
                        <img class="img-fluid" src="images/iconfinder-link.svg" alt="iconfinder">
                      </div>
                      <p class="card-text better-card-text mb-0">Blink Two Camera Indoor System, 1080P HD in</p>
                      <div class="star-rating mt-2">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-3 d-block d-md-none d-lg-block">
                  <div class="img-box card">
                    <img src="images/blink.jpg" class="img-fluid" alt="">
                    <div class="card-body">
                      <div class="icon-onhover mb-3">
                        <img class="img-fluid" src="images/iconfinder-link.svg" alt="iconfinder">
                      </div>
                      <p class="card-text better-card-text mb-0">Blink Two Camera Indoor System, 1080P HD in</p>
                      <div class="star-rating mt-2">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="carousel-item">
              <div class="row">
                <div class="col-sm-3 col-md-4 col-lg-3">
                  <div class="img-box card">
                    <img src="images/blink.jpg" class="img-fluid" alt="">
                    <div class="card-body">
                      <p class="card-text better-card-text mb-0">Blink Two Camera Indoor System, 1080P HD in</p>
                      <div class="star-rating mt-2">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-3 col-md-4 col-lg-3">
                  <div class="img-box card">
                    <img src="images/gul-2.jpg" class="img-fluid" alt="">
                    <div class="card-body">
                      <p class="card-text better-card-text mb-0">Blink Two Camera Indoor System, 1080P HD in</p>
                      <div class="star-rating mt-2">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-3 col-md-4 col-lg-3">
                  <div class="img-box card">
                    <img src="images/gul.jpg" class="img-fluid" alt="">
                    <div class="card-body">
                      <p class="card-text better-card-text mb-0">Blink Two Camera Indoor System, 1080P HD in</p>
                      <div class="star-rating mt-2">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-3 d-block d-md-none d-lg-block">
                  <div class="img-box card">
                    <img src="images/blink.jpg" class="img-fluid" alt="">
                    <div class="card-body">
                      <p class="card-text better-card-text mb-0">Blink Two Camera Indoor System, 1080P HD in</p>
                      <div class="star-rating mt-2">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="carousel-item">
              <div class="row">
                <div class="col-sm-3 col-md-4 col-lg-3">
                  <div class="img-box card">
                    <img src="images/blink.jpg" class="img-fluid" alt="">
                    <div class="card-body">
                      <p class="card-text better-card-text mb-0">Blink Two Camera Indoor System, 1080P HD in</p>
                      <div class="star-rating mt-2">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-3 col-md-4 col-lg-3">
                  <div class="img-box card">
                    <img src="images/gul-2.jpg" class="img-fluid" alt="">
                    <div class="card-body">
                      <p class="card-text better-card-text mb-0">Blink Two Camera Indoor System, 1080P HD in</p>
                      <div class="star-rating mt-2">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-3 col-md-4 col-lg-3">
                  <div class="img-box card">
                    <img src="images/gul.jpg" class="img-fluid" alt="">
                    <div class="card-body">
                      <p class="card-text better-card-text mb-0">Blink Two Camera Indoor System, 1080P HD in</p>
                      <div class="star-rating mt-2">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-3 d-block d-md-none d-lg-block">
                  <div class="img-box card">
                    <img src="images/blink.jpg" class="img-fluid" alt="">
                    <div class="card-body">
                      <p class="card-text better-card-text mb-0">Blink Two Camera Indoor System, 1080P HD in</p>
                      <div class="star-rating mt-2">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- Carousel controls -->
          <a class="carousel-control-prev" href="#myCarousel" data-slide="prev">
            <i class="fa fa-chevron-left"></i>
          </a>
          <a class="carousel-control-next" href="#myCarousel" data-slide="next">
            <i class="fa fa-chevron-right"></i>
          </a>
        </div>
      </div>
    </div>
  </div>




  <?php include 'include/bottom_links.php'; ?>
  <?php include 'include/footer.php'; ?>

</body>

</html>