<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<!-- <script src="js/libs/jquery.js"></script> -->

<script src="https://www.google.com/recaptcha/api.js"></script>
<script src="https://www.google.com/recaptcha/api.js?render=6LcpwU4cAAAAAATwBfZ6_9uGNUF0QMswm2SJWNvv"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
<script src="https://unpkg.com/js-offcanvas@1.2.0/dist/_js/js-offcanvas.pkgd.min.js"></script>

<script>
 $('.dropdown-menu').click(function(e) {
    e.stopPropagation();
});

$(function() {
  $('#ChangeToggle').click(function() {
      alert("change");
    $('#navbar-hamburger').toggleClass('hidden');
    $('#navbar-close').toggleClass('hidden');  
  });
});
/**
 * This was built using the scrollie jQuery Plugin
 * https://github.com/Funsella/jquery-scrollie
 */

if ($(window).scrollTop() > 20){
    $('.toggle-bg-header').addClass( "blue-blue");
}
else {
    $('.toggle-bg-header').removeClass("blue-blue");
}
    
(function( $ ){
  $.fn.appendAround = function(){
    return this.each(function(){

      var $self = $( this ),
          att = "data-set",
          $parent = $self.parent(),
          parent = $parent[ 0 ],
          attval = $parent.attr( att ),
          $set = $( "["+ att +"='" + attval + "']" );

      function isHidden( elem ){
        return $(elem).css( "display" ) === "none";
      }

      function appendToVisibleContainer(){
        if( isHidden( parent ) ){
          var found = 0;
          $set.each(function(){
            if( !isHidden( this ) && !found ){
              $self.appendTo( this );
              found++;
              parent = this;
            }
          });
        }
      }

      appendToVisibleContainer();

      $(window).bind( "resize", appendToVisibleContainer );

    });
  };
}( jQuery ));

$( function(){
  $( document ).trigger( "enhance" );

  $( '#left' ).offcanvas( {
    modifiers: "right,overlay",
    triggerButton: '.js-offcanvas-toggler',
    onInit :  function() {
      $(this).removeClass('is-hidden');
    }
  } );
  $( ".js-append-around" ).appendAround();
});
</script>