<footer class="rop-footer">
  <div class="brands-section">
    <div class="container-fluid">
      <div class="row no-gutters justify-content-between">
        <div class="col-4 px-2 py-3 px-md-4 py-md-5  text-center col-sm-4 d-sm-flex col-xl-auto align-items-center">
          <div class="circulated-img mr-sm-3">
            <img class="img-fluid w-100" src="images/circulated.png" alt="circulated selection">
          </div>
          <h3 class="d-inline-block brands-section-heading mb-0">Curated Selection</h3>
        </div>
        <div class="col-4 px-2 py-3 px-md-4 py-md-5 text-center col-sm-4 d-sm-flex col-xl-auto align-items-center">
          <div class="circulated-img mr-sm-3">
            <img class="img-fluid w-100" src="images/brands.png" alt="Top Brands">
          </div>
          <h3 class="d-inline-block brands-section-heading mb-0">Top Brands</h3>
        </div>
        <div class="col-4 px-2 py-3 px-md-4 py-md-5 text-center col-sm-4 d-sm-flex col-xl-auto align-items-center">
          <div class="circulated-img mr-sm-3">
            <img class="img-fluid w-100" src="images/payments.png" alt="Flexible Payments">
          </div>
          <h3 class="d-inline-block brands-section-heading mb-0">Flexible Payments</h3>
        </div>
      </div>
    </div>
  </div>

  <div class="footer-items px-4 py-5">
    <div class="container-fluid">
      <div class="row no-gutters align-items-center">
        <div class="footer-content col-sm-12  col-lg-7 ">
          <div class="inner row  justify-content-between justify-content-md-start">
            <div class="coll col-4 col-sm-4 footer-links  mb-lg-0">
              <div class="menu-footer">
                <ul class="footer-links">
                  <li> <a href="">About Us</a></li>
                  <li> <a href="">Shipping & Returns</a></li>
                  <li> <a href="">Privacy Policy</a></li>
                  <li> <a href="">Better1 Reviews</a></li>
                </ul>
              </div>
            </div>

            <div class="coll col-4 col-sm-4 footer-links  mb-lg-0">
              <div class="menu-footer">
                <ul class="footer-links">
                  <li> <a href="">FAQ</a></li>
                  <li> <a href="">Terms of Service</a></li>
                  <li> <a href="">Protection Plan</a></li>
                  <li> <a href="">Better1 Gift Card</a></li>
                </ul>
              </div>
            </div>
            <div class="coll col-4 col-sm-4 footer-links  mb-lg-0">
              <div class="menu-footer">
                <ul class="footer-links">
                  <li> <a href="">Contact Us</a></li>
                  <li> <a href="">Better1 Membership</a></li>
                  <li> <a href="">Order Tracking</a></li>
                  <li> <a href="">Better1 App</a></li>
                </ul>
              </div>
            </div>

            <div class="col-4 col-sm-4">
              <p>
                <img class="img-fluid w-100" src="images/visa.png" alt="visa">
              </p>
              <div class="d-flex">
                <img class="img-fluid bbb-google" src="images/bbb.png" alt="visa">
                <img class="img-fluid bbb-google" src="images/google.png" alt="visa">
              </div>
            </div>

          </div>
        </div>

        <div class="col-sm-12 col-lg-5">
          <div class="rop-form my-2">
            <form action="" method="post">
              <div class="form-heading">
                <h3>Sign Up & Get $5 OFF!</h3>
              </div>
              <div class="row">
                <div class="form-group col-6 col-md-4 col-lg-6">
                  <input type="text" class="form-control" placeholder="First Name">
                </div>
                <div class="form-group  col-6 col-md-4 col-lg-6">
                  <input type="text" class="form-control" placeholder="Last Name">
                </div>
              </div>
              <div class="row">
                <div class="form-group col-12 col-md-8 col-lg-12">
                  <input type="email" class="form-control" placeholder="Email Address">
                </div>

              </div>

              <div class="captcha-section">
                <label class="captcha-label font-weight-bolder" for="captcha">CAPTCHA</label>
                <div class="g-recaptcha" data-sitekey="6LcpwU4cAAAAAATwBfZ6_9uGNUF0QMswm2SJWNvv"></div>
              </div>
              <div class="input-btn">
                <button class="btn btn-danger">Sign Up</button>
              </div>

            </form>
          </div>
        </div>

      </div>
    </div>
  </div>

  <div class="copyright-section px-1 py-2 px-md-4 py-md-3">
    <div class="container-fluid">
      <div class="d-flex">
        <div class="text-copyright">
          <a class="text-decoration-none text-white" href="">© 2021 Better1 – Better Products For Better Living. All
            rights reserved. </a>
        </div>
        <div class="social-media-icons ml-auto">
          <a href="#/" class="text-decoration-none text-white">
            <i class="fa font-size-social mr-1 fa-instagram" aria-hidden="true"></i>
          </a>
          <a href="#/" class="text-decoration-none text-white">
            <i class="fa font-size-social mr-1 fa-facebook-square" aria-hidden="true"></i>
          </a>
          <a href="#/" class="text-decoration-none text-white">
            <i class="fa font-size-social mr-1 fa-youtube-play" aria-hidden="true"></i>
          </a>
        </div>
      </div>
    </div>
  </div>

</footer>