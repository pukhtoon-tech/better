<section class="top-bar w-100">
  <div class="container-fluid p-0">
    <div class="row no-gutters">
      <div class="col-12 col-md-3 col-xs-6 d-none d-sm-none d-md-block">
        <div class="info-mail d-none d-md-block">
          <a href="mailto:info@better1.com" class="email-info text-decoration-none text-white">
            <i class="fa font-size-envelope mr-1 fa-envelope" aria-hidden="true"></i>
            info@better1.com
          </a>
        </div>
      </div>

      <div class="col-12 col-md-6 col-xs-12">
        <div class="product-line text-center font-weight-bolder">
          Proudly Canadian!ðŸ‡¨ðŸ‡¦
        </div>
      </div>
      <div class="col-md-3 col-xs-6 text-right d-none d-sm-none d-md-block">
        <div class="info-mail d-none d-md-block">
          <a href="mailto:info@better1.com" class="email-info text-decoration-none text-white">
            <i class="fa font-size-envelope mr-1 fa-phone" aria-hidden="true"></i>
            1-888-621-3237
          </a>
        </div>
      </div>

    </div>
  </div>
</section>

<header class="home">
  <div class="c-offcanvas-content-wrap mobile-fixed">
    <nav class="navbar px-md-5 navbar-expand-md navbar-dark toggle-bg-header">
      <div class="position-relative mr-5">
        <a class="navbar-brand header-logo" href="index.php">
          <img class="better-logo" src="images/s.png" alt="logo">
        </a>
      </div>
      <div class="cart-notification ml-auto d-block d-lg-none ">
        <a href="#/" class="cart-icon-section position-relative">
          <span>0</span>
          <img class="intrinsic" src="images/updated-cart-icon.svg" alt="">
        </a>
      </div>

      <div class="search-icon-small d-block d-lg-none mr-5 mr-md-3 ml-md-3 ml-4">
        <img src="images/search-icon.svg" alt="search icon">
      </div>

      <button class="navbar-toggler better-navbar-toggler js-offcanvas-toggler" data-button-options='{"wrapText":false}'
        aria-label="Toggle navigation">
        <span class="navbar-toggler-ico"></span>
        <span class="navbar-toggler-ico"></span>
        <span class="navbar-toggler-ico"></span>
      </button>



      <div class="collapse navbar-collapse" id="navbarsExampleDefault" data-set="bs">

        <div class="input-group d-none d-xl-flex w-25 ml-auto mr-4">
          <input type="text" class="form-control" placeholder="Search">
          <div class="input-group-append">
            <button class="btn btn-bg" type="button">
              <i class="fa text-white fa-search"></i>
            </button>
          </div>
        </div>


        <ul class="navbar-nav ml-auto-removed better-navbar js-append-around">
          <li class="nav-item d-flex active">
            <img class="d-block d-md-none mr-3" src="images/shop-icon.svg" alt="">
            <a class="nav-link" href="#">Shop</a>
          </li>
          <li class="nav-item dropdown">
            <img class="d-inline-block d-md-none mr-3" src="images/bed.svg" alt="">
            <a class="nav-link dropdown-toggle dropdown-toggle-smalldevices" href="#" id="dropdown01"
              data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Rooms</a>
            <div class="dropdown-menu better-dropdown-menu" aria-labelledby="dropdown01">
              <a class="dropdown-item" href="#">360Â° Shopping</a>
              <a class="dropdown-item" href="#">Family Room</a>
              <a class="dropdown-item" href="#">Kitchen</a>
              <a class="dropdown-item" href="#">Bedroom</a>
              <a class="dropdown-item" href="#">Office</a>
              <a class="dropdown-item" href="#">Washroom</a>
              <a class="dropdown-item" href="#">Gym</a>
              <a class="dropdown-item" href="#">Garrage</a>
            </div>
          </li>

          <li class="nav-item dropdown">
            <img class="d-inline-block d-md-none mr-3" src="images/layers.svg" alt="">
            <a class="nav-link dropdown-toggle dropdown-toggle-smalldevices" href="#" id="dropdown01"
              data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Categories</a>
            <div class="dropdown-menu  better-dropdown-mega-menu" aria-labelledby="dropdown01">


              <?php include 'include/categories-mega-menu.php'; ?>

            </div>
          </li>

          <li class="nav-item dropdown">
            <img class="d-inline-block d-md-none mr-3" src="images/tag.svg" alt="">
            <a class="nav-link dropdown-toggle dropdown-toggle-smalldevices" href="#" id="dropdown01"
              data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Brands</a>
            <div class="dropdown-menu  better-dropdown-mega-menu" aria-labelledby="dropdown01">


              <?php include 'include/categories-mega-menu.php'; ?>

            </div>
          </li>

          <li class="nav-item d-flex">
            <img class="d-block d-md-none mr-3" src="images/icBlog.svg" alt="">
            <a class="nav-link" href="#">Blog</a>
          </li>

        </ul>
        <form class="form-inline my-2 my-lg-0 js-append-around">
          <button class="btn d-none d-lg-block btn-sign-in my-2 my-sm-0" type="submit">Sign-in to enjoy
            benefits</button>
        </form>
        <div class="cart-notification d-none d-lg-flex " style="position: absolute; right: 20px;">
          <a href="#/" class="cart-icon-section position-relative">
            <span>0</span>
            <img class="intrinsic" src="images/updated-cart-icon.svg" alt="">
          </a>
          <div class="search-icon-small d-sm-none d-md-none d-lg-block d-xl-none mr-4 ml-4">
            <img src="images/search-icon.svg" alt="search icon">
          </div>
        </div>



      </div>
    </nav>
  </div>

  <div class="c-offcanvas is-hidden" id="left" role="complementary">

    <div class="navbar p-0">
      <div class="offcanvas-nav d-block w-100 d-md-none" data-set="bs"></div>
    </div>

    <form class="form-inline-small px-5 py-3 d-flex justify-content-center my-2 my-lg-0 js-append-around">
      <button class="btn d-block d-md-none btn-sign-in-mobile my-2 my-sm-0" type="submit">Sign-in to enjoy
        benefits</button>
    </form>

  </div>

</header>

<!-- 
<button class="navbar-toggler d-none better-navbar-toggle js-offcanvas-close"
data-button-options='{"wrapText":false}' aria-label="Toggle navigation">
<i class="fa text-white fa-search"></i>
</button> -->