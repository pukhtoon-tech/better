<ul class="menu">
                <li>
                  <a href="#">Accessories</a>
                  <div class="megadrop">

                    <div class="col">
                      <ul>
                        <li><a href="#">Accessory</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col">
                      <ul>
                        <li><a href="#">Charger</a>
                        </li>
                      </ul>
                    </div>

                  </div>

                </li>
                <li>
                  <a href="#">Audio</a>
                  <div class="megadrop">

                    <div class="col">
                      <ul>
                        <li><a href="#">Headphones</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col">
                      <ul>
                        <li><a href="#">Speakers</a>
                        </li>
                      </ul>
                    </div>

                  </div>

                </li>


                <li>
                  <a href="#">Chargers</a>
                  <div class="megadrop">

                    <div class="col">
                      <ul>
                        <li><a href="#">Headphones</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col">
                      <ul>
                        <li><a href="#">Speakers</a>
                        </li>
                      </ul>
                    </div>

                  </div>

                </li>

                <li>
                  <a href="#">Computing</a>
                  <div class="megadrop">

                    <div class="col">
                      <ul>
                        <li><a href="#">Router</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col">
                      <ul>
                        <li><a href="#">Mesh</a>
                        </li>
                      </ul>
                    </div>

                    <div class="col">
                      <ul>
                        <li><a href="#">Network Expansion</a>
                        </li>
                      </ul>
                    </div>

                  </div>

                </li>

                <li>
                  <a href="#">Connectivity</a>
                  <div class="megadrop">

                    <div class="col">
                      <ul>
                        <li><a href="#">Headphones</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col">
                      <ul>
                        <li><a href="#">Speakers</a>
                        </li>
                      </ul>
                    </div>

                  </div>

                </li>

                <li>
                  <a href="#">Cool Things</a>
                  <div class="megadrop">

                    <div class="col">
                      <ul>
                        <li><a href="#">Headphones</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col">
                      <ul>
                        <li><a href="#">Speakers</a>
                        </li>
                      </ul>
                    </div>

                  </div>

                </li>

                <li>
                  <a href="#">Fitness</a>
                  <div class="megadrop">

                    <div class="col">
                      <ul>
                        <li><a href="#">Headphones</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col">
                      <ul>
                        <li><a href="#">Speakers</a>
                        </li>
                      </ul>
                    </div>

                  </div>

                </li>

                <li>
                  <a href="#">Miscellaneous</a>
                  <div class="megadrop">

                    <div class="col">
                      <ul>
                        <li><a href="#">Headphones</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col">
                      <ul>
                        <li><a href="#">Speakers</a>
                        </li>
                      </ul>
                    </div>

                  </div>

                </li>

                <li>
                  <a href="#">Office Equipment</a>
                  <div class="megadrop">

                    <div class="col">
                      <ul>
                        <li><a href="#">Headphones</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col">
                      <ul>
                        <li><a href="#">Speakers</a>
                        </li>
                      </ul>
                    </div>

                  </div>

                </li>

                <li>
                  <a href="#">Outdoor</a>
                  <div class="megadrop">

                    <div class="col">
                      <ul>
                        <li><a href="#">Headphones</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col">
                      <ul>
                        <li><a href="#">Speakers</a>
                        </li>
                      </ul>
                    </div>

                  </div>

                </li>

                <li>
                  <a href="#">Security</a>
                  <div class="megadrop">

                    <div class="col">
                      <ul>
                        <li><a href="#">Headphones</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col">
                      <ul>
                        <li><a href="#">Speakers</a>
                        </li>
                      </ul>
                    </div>

                  </div>

                </li>

                <li>
                  <a href="#">Smart Home</a>
                  <div class="megadrop">

                    <div class="col">
                      <ul>
                        <li><a href="#">Headphones</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col">
                      <ul>
                        <li><a href="#">Speakers</a>
                        </li>
                      </ul>
                    </div>

                  </div>

                </li>

                <li>
                  <a href="#">Travel</a>
                  <div class="megadrop">

                    <div class="col">
                      <ul>
                        <li><a href="#">Headphones</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col">
                      <ul>
                        <li><a href="#">Speakers</a>
                        </li>
                      </ul>
                    </div>

                  </div>

                </li>

                <li>
                  <a href="#">Video</a>
                  <div class="megadrop">

                    <div class="col">
                      <ul>
                        <li><a href="#">Headphones</a>
                        </li>
                      </ul>
                    </div>
                    <div class="col">
                      <ul>
                        <li><a href="#">Speakers</a>
                        </li>
                      </ul>
                    </div>

                  </div>

                </li>
              </ul>